<div align='center'>
    <h1>berry</h1><br>
</div>

A healthy, bite-sized window manager written in C over the XLib library.

![Screenshot](https://external-preview.redd.it/A8DWRA2txIQM8g_CpXPXAoC-wU7CSrjJO2UdCW8Nv7Y.png?auto=webp&s=3f65c783c54fd2df1ffe0be7a9f3dfa9ae54a22c)

# Usage

For usage and documentation, please visit the project website [berrywm.org](https://berrywm.org)