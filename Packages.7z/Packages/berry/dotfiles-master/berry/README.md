<div align='center'>
    <h1>berry</h1><br>
</div>

`berry` is a small, lightweight floating window manager for `XOrg`.
I wrote `berry` myself from sratch over the summer in college.
Although it fits my needs very well, it might not work as intended on your system
or with your workflow. The full project can be found [here](https://github.com/JLErvin/berry) 

`berry` use a shell script for configuration, similar to `bspwm` or `herbstluftwm`.
I use my themeing application, `squash`, to generate colors for berry that I source in `autostart`.
