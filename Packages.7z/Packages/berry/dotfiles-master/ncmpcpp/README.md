<div align='center'>
    <h1>ncmpcpp</h1><br>
</div>

`nmcpcpp` is a minimal command-line frontend for music players such as `mpd`.
I use `ncmpcpp` with `mopidy-spotify`.

![Screenshot](https://i.imgur.com/9eiIsCi.png)

