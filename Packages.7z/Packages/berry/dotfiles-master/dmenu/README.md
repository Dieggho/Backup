<div align='center'>
    <h1>dmenu</h1><br>
</div>

`dmenu` is a simple application launcher. 
I used to use `rofi` but found that I wasn't using many of its features,
so I switched to a `dmenu` for a simpler experience. 

I have included a custom script to start `dmenu` which works with my themeing
application, `squash` to set `dmenu`'s fonts and colors.

