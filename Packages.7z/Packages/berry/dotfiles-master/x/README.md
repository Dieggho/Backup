<div align='center'>
    <h1>X</h1><br>
</div>

These are my configuration files for `XOrg`. 

`.xinitrc` is run on startup and starts my window manager.

`.Xresources` is used for applications like `urxvt` and defines many system-wide variables.
You will notice that I do not include any color information in `.Xresources`. 
Instead, I source from my themeing application, `squash`, which manages my colors.

