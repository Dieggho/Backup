# 32-bit-backup
The same as my dwm stuff but focused on arch32
